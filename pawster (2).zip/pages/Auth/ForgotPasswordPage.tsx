import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../../components/Button';
import { supabase, isSupabaseConfigured } from '../../supabaseClient';

const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    if (!isSupabaseConfigured()) {
       await new Promise(r => setTimeout(r, 1000));
       setMessage("If this were real, an email would be sent to " + email);
       setLoading(false);
       return;
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setLoading(false);
    if (error) {
      alert(error.message);
    } else {
      setMessage("Check your email for the password reset link");
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-2xl shadow-sm border border-gray-100">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Reset Password</h2>
          <p className="mt-2 text-sm text-gray-600">
            Enter your email to receive instructions.
          </p>
        </div>

        {message ? (
          <div className="bg-green-50 text-green-700 p-4 rounded-lg text-center">
            {message}
            <div className="mt-4">
              <Link to="/login" className="text-pawster-teal font-bold hover:underline">Back to Login</Link>
            </div>
          </div>
        ) : (
          <form className="mt-8 space-y-6" onSubmit={handleReset}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-pawster-teal focus:border-pawster-teal sm:text-sm"
              />
            </div>
            <Button type="submit" className="w-full" isLoading={loading}>
              Send Reset Link
            </Button>
            <div className="text-center">
              <Link to="/login" className="text-sm text-gray-500 hover:text-gray-900">Cancel</Link>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPasswordPage;