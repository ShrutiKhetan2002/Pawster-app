import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import { supabase, isSupabaseConfigured } from '../../supabaseClient';

interface LoginPageProps {
  onLoginSuccess: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (!isSupabaseConfigured()) {
        await new Promise(r => setTimeout(r, 1000));
        if (email === 'fail@test.com') throw new Error("Invalid credentials");
        onLoginSuccess();
        navigate('/dashboard');
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      onLoginSuccess();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Failed to login');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] flex items-center justify-center bg-pawster-bg py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Bg Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-pawster-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-pawster-secondary/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-md w-full space-y-8 bg-white/80 backdrop-blur-xl p-10 rounded-[2.5rem] shadow-soft border border-white/50 relative z-10">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-gradient-to-tr from-pawster-primary to-pawster-primaryDark rounded-2xl flex items-center justify-center text-3xl shadow-lg shadow-pawster-primary/30 mb-6 text-white">
            🐾
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Welcome Back</h2>
          <p className="mt-2 text-sm text-slate-500">
            Or <Link to="/signup" className="font-bold text-pawster-primary hover:text-pawster-primaryDark underline decoration-2 decoration-transparent hover:decoration-pawster-primary transition-all">start your 14-day free trial</Link>
          </p>
        </div>
        
        {error && (
          <div className="bg-rose-50 border border-rose-100 text-rose-600 px-4 py-3 rounded-xl text-sm font-medium">
            {error}
          </div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-bold text-slate-700 ml-1 mb-1">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full px-4 py-3.5 border border-slate-200 placeholder-slate-400 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-pawster-primary focus:border-transparent bg-slate-50/50 transition-all"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-bold text-slate-700 ml-1 mb-1">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full px-4 py-3.5 border border-slate-200 placeholder-slate-400 text-slate-900 rounded-xl focus:outline-none focus:ring-2 focus:ring-pawster-primary focus:border-transparent bg-slate-50/50 transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 text-pawster-primary focus:ring-pawster-primary border-slate-300 rounded"
              />
              <label htmlFor="remember-me" className="ml-2 block text-sm text-slate-600 font-medium">
                Remember me
              </label>
            </div>

            <div className="text-sm">
              <Link to="/forgot-password" className="font-bold text-pawster-primary hover:text-pawster-primaryDark">
                Forgot password?
              </Link>
            </div>
          </div>

          <Button type="submit" className="w-full h-12 text-lg shadow-xl shadow-pawster-primary/20" isLoading={loading} size="lg">
            Sign in
          </Button>
        </form>
        
        {!isSupabaseConfigured() && (
          <div className="mt-6 p-3 bg-slate-50 rounded-xl text-xs text-center text-slate-400 font-medium border border-slate-100">
             Running in Preview Mode
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginPage;