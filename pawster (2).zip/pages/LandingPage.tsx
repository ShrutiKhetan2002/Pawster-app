import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';

const LandingPage: React.FC = () => {
  return (
    <div className="bg-pawster-bg overflow-x-hidden font-sans">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 lg:pt-32 lg:pb-48 overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-0 right-0 -mr-32 -mt-32 w-[800px] h-[800px] bg-pawster-secondary/40 rounded-full mix-blend-multiply filter blur-[80px] opacity-70 animate-float"></div>
        <div className="absolute bottom-0 left-0 -ml-32 -mb-32 w-[600px] h-[600px] bg-pawster-primary/20 rounded-full mix-blend-multiply filter blur-[80px] opacity-60 animate-float" style={{ animationDelay: '2s' }}></div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            
            <div className="text-center lg:text-left space-y-8 animate-fade-in-up">
              <span className="inline-flex items-center gap-2 py-2 px-5 rounded-full bg-white border border-slate-200 shadow-sm text-pawster-accent text-sm font-bold tracking-wide">
                <span className="animate-pulse-slow">❤️</span> America's favorite pet community
              </span>
              
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-pawster-text leading-[1.05] tracking-tight">
                Share the Love, <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-pawster-primary to-blue-500">
                  One Paw at a Time.
                </span>
              </h1>
              
              <p className="text-xl text-pawster-textLight max-w-lg mx-auto lg:mx-0 leading-relaxed font-medium">
                Connect with trusted local pet lovers. Find a playmate for your pet or a furry friend for yourself.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
                <Link to="/explore">
                   <Button size="lg" className="w-full sm:w-auto shadow-xl shadow-pawster-primary/30 h-14 px-8 text-lg">
                     Find a Pet
                   </Button>
                </Link>
                <Link to="/signup">
                   <Button variant="secondary" size="lg" className="w-full sm:w-auto h-14 px-8 text-lg">
                     List Your Pet
                   </Button>
                </Link>
              </div>
              
              <div className="pt-8 flex items-center justify-center lg:justify-start gap-4 text-sm text-gray-500 font-medium">
                <div className="flex -space-x-4">
                  {[10, 11, 12, 13].map((i) => (
                    <img key={i} className="w-12 h-12 rounded-full border-4 border-white shadow-soft" src={`https://picsum.photos/id/${i}/100/100`} alt="User" />
                  ))}
                </div>
                <div className="pl-2">
                  <div className="text-pawster-text font-bold text-base">2,000+ happy members</div>
                  <div className="text-xs text-pawster-primaryDark font-bold tracking-wide">★★★★★ RATED 4.9/5</div>
                </div>
              </div>
            </div>

            <div className="relative animate-fade-in-up hidden lg:block" style={{ animationDelay: '0.2s' }}>
              <div className="relative rounded-[3rem] overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-700 ease-out border-[8px] border-white">
                 <img 
                  src="https://images.unsplash.com/photo-1450778869180-41d0601e046e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                  alt="Happy dog with owner" 
                  className="w-full object-cover h-[600px] transform hover:scale-105 transition-transform duration-1000"
                />
                
                {/* Floating Card 1 */}
                <div className="absolute top-10 left-[-20px] bg-white/90 backdrop-blur-xl rounded-3xl p-5 shadow-glow max-w-xs animate-float border border-white/50">
                   <div className="flex items-center gap-4">
                     <div className="w-12 h-12 rounded-2xl bg-green-100 flex items-center justify-center text-2xl shadow-inner">🥎</div>
                     <div>
                       <p className="font-bold text-gray-900">Playtime!</p>
                       <p className="text-xs text-gray-500 font-medium">Today, 2:00 PM</p>
                     </div>
                   </div>
                </div>

                {/* Floating Card 2 */}
                <div className="absolute bottom-12 right-[-20px] bg-white/90 backdrop-blur-xl rounded-3xl p-5 shadow-glow max-w-xs animate-float border border-white/50" style={{ animationDelay: '1.5s' }}>
                   <div className="flex items-center gap-4">
                     <div className="w-12 h-12 rounded-2xl bg-orange-100 flex items-center justify-center text-2xl shadow-inner">🐶</div>
                     <div>
                       <p className="font-bold text-gray-900 italic">"Best weekend!"</p>
                       <p className="text-xs text-gray-500 font-bold">— Sarah & Boomer</p>
                     </div>
                   </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-white relative">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-3xl md:text-5xl font-extrabold text-pawster-text mb-6 tracking-tight">How Pawster Works</h2>
            <p className="text-xl text-pawster-textLight">Simple, safe, and secure for everyone involved. Start your journey in 3 steps.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {[
              { title: 'Create a Profile', icon: '📝', desc: 'Sign up as an owner to list your pet, or as a borrower to find a companion.', color: 'bg-blue-50 text-blue-500 border-blue-100' },
              { title: 'Connect & Book', icon: '🤝', desc: 'Browse pets nearby. Chat with owners. Request a booking time securely.', color: 'bg-teal-50 text-teal-500 border-teal-100' },
              { title: 'Earn & Enjoy', icon: '🦴', desc: 'Owners earn Paw Credits for pet expenses. Borrowers get unconditional love.', color: 'bg-amber-50 text-amber-500 border-amber-100' }
            ].map((step, idx) => (
              <div key={idx} className={`group p-10 rounded-[2.5rem] border ${step.color.split(' ').pop()} bg-white hover:shadow-soft hover:-translate-y-2 transition-all duration-300 text-center relative overflow-hidden`}>
                <div className={`w-24 h-24 ${step.color.split(' ').slice(0, 2).join(' ')} rounded-3xl flex items-center justify-center text-4xl mx-auto mb-8 shadow-inner group-hover:scale-110 transition-transform duration-300`}>
                  {step.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">{step.title}</h3>
                <p className="text-gray-500 leading-relaxed font-medium">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Banner */}
      <section className="py-24 bg-gradient-to-br from-pawster-primaryDark to-teal-600 relative overflow-hidden">
        {/* Decorative Circles */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-white opacity-5 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-white opacity-5 rounded-full translate-x-1/3 translate-y-1/3 blur-3xl"></div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
           <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-16">Safety First, Always.</h2>
           <div className="grid md:grid-cols-3 gap-8">
              {[
                { title: "Verified Profiles", desc: "Every member goes through ID verification.", icon: "🛡️" },
                { title: "Secure Payments", desc: "Funds held in escrow until booking completes.", icon: "🔒" },
                { title: "24/7 Support", desc: "Real humans ready to help whenever you need.", icon: "📞" }
              ].map((item, i) => (
                <div key={i} className="glass-panel bg-white/10 border border-white/20 rounded-3xl p-8 hover:bg-white/15 transition-colors duration-300">
                  <div className="text-5xl mb-6 drop-shadow-lg">{item.icon}</div>
                  <div className="font-bold text-2xl text-white mb-3">{item.title}</div>
                  <p className="text-teal-50 opacity-90 font-medium leading-relaxed">{item.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </section>
      
      {/* Final CTA */}
      <section className="py-32 text-center bg-pawster-bg">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto bg-pawster-secondary/20 rounded-[4rem] p-12 md:p-24 relative overflow-hidden border border-pawster-secondary/30 shadow-soft">
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-extrabold text-pawster-text mb-8">Ready to make a new friend?</h2>
              <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto font-medium">Join the Pawster community today and start sharing the love.</p>
              <Link to="/signup">
                <Button size="lg" className="text-lg px-12 py-5 shadow-xl shadow-pawster-primary/25 rounded-full">Get Started Now</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;