import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Pet } from '../types';
import { petService } from '../services/petService';
import PetCard from '../components/PetCard';
import Button from '../components/Button';
import { supabase } from '../supabaseClient';

const DashboardPage: React.FC = () => {
  const [myPets, setMyPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);
  const [credits] = useState(1250); 
  const [userName, setUserName] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();

      if (userError || !user) {
        setMyPets([]);
        return;
      }

      const { data: profileData } = await supabase
        .from('profiles')
        .select('name')
        .eq('id', user.id)
        .maybeSingle();

      setUserName(profileData?.name || user.email || 'Friend');

      const pets = await petService.getMyPets(user.id);
      setMyPets(pets);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to remove this pet?')) {
      await petService.deletePet(id);
      await loadDashboardData();
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      {/* Header / Stats */}
      <div className="grid lg:grid-cols-3 gap-8 mb-16">
        {/* Welcome Block */}
        <div className="lg:col-span-2 bg-white rounded-4xl p-10 shadow-soft border border-slate-100 flex flex-col justify-center relative overflow-hidden">
          <div className="relative z-10">
            <h1 className="text-3xl md:text-5xl font-extrabold text-slate-800 mb-4">
              Hello, <span className="text-pawster-primary">{userName}</span> 👋
            </h1>
            <p className="text-slate-500 text-lg mb-8 max-w-lg leading-relaxed">
              Welcome back to your dashboard. Check on your pets, manage bookings, or find a new sitter today.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Link to="/explore">
                <Button variant="outline" className="border-slate-200 text-slate-600 hover:border-pawster-primary hover:text-pawster-primary">Find a Sitter</Button>
              </Link>
              <Link to="/pets/new">
                <Button className="shadow-lg shadow-pawster-primary/20">List a Pet</Button>
              </Link>
            </div>
          </div>
          <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none">
             <svg width="300" height="300" viewBox="0 0 200 200"><path fill="#2DD4BF" d="M44.7,-76.4C58.9,-69.2,71.8,-59.1,81.6,-46.6C91.4,-34.1,98.1,-19.2,95.8,-4.1C93.5,11.1,82.2,26.4,70.6,39.3C59,52.2,47.1,62.7,33.9,70.1C20.7,77.5,6.2,81.8,-7.4,80.3C-21,78.8,-33.6,71.6,-45.1,62.8C-56.6,54,-66.9,43.6,-74.3,31.4C-81.7,19.2,-86.1,5.2,-84.6,-8.3C-83.1,-21.8,-75.7,-34.8,-65.4,-44.6C-55.1,-54.4,-41.9,-60.9,-28.9,-68.8C-15.9,-76.7,-3.1,-85.9,8.5,-84.2C20.1,-82.5,30.5,-69.9,44.7,-76.4Z" transform="translate(100 100)" /></svg>
          </div>
        </div>

        {/* Credit Card Widget */}
        <div className="bg-gradient-to-br from-pawster-primary to-pawster-primaryDark rounded-4xl p-8 text-white shadow-glow relative overflow-hidden flex flex-col justify-between min-h-[240px]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full translate-x-10 -translate-y-10 blur-xl"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-10 rounded-full -translate-x-5 translate-y-5 blur-xl"></div>

          <div className="relative z-10 flex justify-between items-start">
            <div>
              <p className="text-teal-100 font-bold text-xs uppercase tracking-widest mb-1">
                Balance
              </p>
              <h2 className="text-5xl font-extrabold">{credits}</h2>
              <p className="text-teal-100 text-sm mt-1">Paw Credits</p>
            </div>
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-2xl">🐾</div>
          </div>

          <div className="relative z-10 mt-6">
            <Button
              size="sm"
              className="w-full bg-white text-pawster-primaryDark hover:bg-teal-50 border-none shadow-none font-bold"
            >
              Redeem Credits
            </Button>
          </div>
        </div>
      </div>

      {/* My Pets Section */}
      <div className="mb-20">
        <div className="flex justify-between items-end mb-8 border-b border-gray-100 pb-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
              <span className="text-3xl">🐕</span> My Listed Pets
            </h2>
          </div>
          <Link to="/pets/new" className="text-pawster-primary font-bold hover:text-pawster-primaryDark text-sm">
            + Add New
          </Link>
        </div>

        {loading ? (
          <div className="flex justify-center py-20 bg-white rounded-3xl border border-gray-100">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pawster-primary"></div>
          </div>
        ) : myPets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {myPets.map((pet) => (
              <PetCard
                key={pet.id}
                pet={pet}
                isOwner
                onDelete={handleDelete}
                onEdit={(id) => navigate(`/pets/edit/${id}`)}
              />
            ))}

            {/* Add New Card (Dashed) */}
            <Link
              to="/pets/new"
              className="group border-3 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center p-6 text-slate-400 hover:border-pawster-primary hover:text-pawster-primary hover:bg-pawster-primary/5 transition-all duration-300 min-h-[400px]"
            >
              <div className="w-20 h-20 rounded-full bg-slate-50 group-hover:bg-white group-hover:shadow-lg flex items-center justify-center text-3xl mb-4 transition-all duration-300 text-slate-300 group-hover:text-pawster-primary">
                +
              </div>
              <span className="font-bold text-lg">Add Another Pet</span>
            </Link>
          </div>
        ) : (
          <div className="text-center py-24 bg-white rounded-3xl border border-dashed border-slate-200">
            <div className="text-7xl mb-6 opacity-80 animate-bounce-slow">🦴</div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">No pets listed yet</h3>
            <p className="text-slate-500 mb-8 max-w-md mx-auto">
              Share your furry friend with the community! It takes less than 2 minutes.
            </p>
            <Link to="/pets/new">
              <Button size="lg" className="shadow-lg">
                List Your First Pet
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <div className="max-w-4xl">
        <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
          <span className="text-3xl">📅</span> Recent Activity
        </h2>
        <div className="bg-white rounded-4xl shadow-soft border border-slate-100 overflow-hidden">
          {[
            {
              user: 'Jane Doe',
              action: 'booked',
              pet: 'Barnaby',
              time: '2h ago',
              credits: 30,
              color: 'bg-green-100 text-green-600',
              initials: 'JD',
            },
            {
              user: 'Mike K.',
              action: 'messaged about',
              pet: 'Luna',
              time: '5h ago',
              credits: 0,
              color: 'bg-blue-100 text-blue-600',
              initials: 'MK',
            },
            {
              user: 'Sarah J.',
              action: 'left a review for',
              pet: 'Barnaby',
              time: '1d ago',
              credits: 0,
              color: 'bg-purple-100 text-purple-600',
              initials: 'SJ',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-6 flex items-center gap-4 hover:bg-slate-50 transition duration-200 border-b border-slate-50 last:border-0"
            >
              <div
                className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center text-sm font-extrabold shadow-sm`}
              >
                {item.initials}
              </div>
              <div className="flex-1">
                <p className="text-slate-800 font-medium text-base">
                  <span className="font-bold">{item.user}</span> {item.action}{' '}
                  <span className="font-bold text-pawster-primaryDark">{item.pet}</span>
                </p>
                <p className="text-xs text-slate-400 mt-1 uppercase tracking-wide font-bold">
                  {item.time}
                </p>
              </div>
              {item.credits > 0 && (
                <span className="px-4 py-1.5 bg-green-50 text-green-700 text-xs font-bold rounded-full border border-green-100">
                  + {item.credits} Credits
                </span>
              )}
              <Button variant="ghost" size="sm" className="hidden sm:inline-flex">
                View
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;