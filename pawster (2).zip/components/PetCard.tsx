import React from 'react';
import { Pet } from '../types';
import Button from './Button';

interface PetCardProps {
  pet: Pet;
  isOwner?: boolean;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onBook?: (id: string) => void;
}

const PetCard: React.FC<PetCardProps> = ({ pet, isOwner, onEdit, onDelete, onBook }) => {
  // Defensive checks
  const imageUrl = pet.image_url || 'https://via.placeholder.com/400?text=No+Image';
  const temperament = pet.temperament || 'Friendly';
  const description = pet.description || 'No description provided.';
  
  // Safe access to first temperament tag
  const firstTemperament = (typeof temperament === 'string' && temperament.split) 
    ? temperament.split(' ')[0] 
    : 'Friendly';

  return (
    <div className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-glow transition-all duration-500 hover:-translate-y-2 flex flex-col h-full border border-slate-100">
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={imageUrl} 
          alt={pet.name} 
          className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-80"></div>
        
        {/* Price Badge */}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-2xl text-sm font-bold text-pawster-text shadow-lg flex items-center gap-1 border border-white/50">
          <span className="text-lg text-pawster-primaryDark">${pet.hourly_rate}</span>
          <span className="text-xs text-slate-400 font-normal">/hr</span>
        </div>

        {/* Floating Species Badge */}
        <div className="absolute top-4 left-4">
           <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-md shadow-sm border border-white/20
             ${pet.species === 'Dog' ? 'bg-blue-500/80 text-white' : 
               pet.species === 'Cat' ? 'bg-purple-500/80 text-white' : 
               pet.species === 'Bird' ? 'bg-yellow-500/80 text-white' : 'bg-gray-500/80 text-white'
             }`}>
             {pet.species}
           </span>
        </div>
        
        {/* Name Overlay */}
        <div className="absolute bottom-0 left-0 p-6 w-full text-white transform transition-transform duration-300 group-hover:translate-y-[-8px]">
          <h3 className="text-3xl font-extrabold leading-none mb-1 drop-shadow-md">{pet.name}</h3>
          <p className="text-sm font-medium text-slate-200 drop-shadow-md flex items-center gap-2">
            <span>{pet.breed}</span>
            <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
            <span>{pet.age} {pet.age === 1 ? 'yr' : 'yrs'}</span>
          </p>
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow relative bg-white">
        {/* Overlap fix for rounded corners visually */}
        <div className="absolute -top-6 left-0 right-0 h-6 bg-gradient-to-t from-white to-transparent"></div>

        <div className="mb-4">
           <span className="inline-block bg-pawster-bg text-pawster-textLight text-xs font-bold px-3 py-1 rounded-lg border border-slate-200">
             ✨ {firstTemperament}
           </span>
        </div>
        
        <p className="text-pawster-textLight text-sm mb-6 line-clamp-3 leading-relaxed flex-grow">
          {description}
        </p>

        {/* Action Area */}
        <div className="mt-auto pt-4 border-t border-slate-50">
          {isOwner ? (
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" size="sm" className="w-full" onClick={() => onEdit?.(pet.id)}>Edit</Button>
              <Button variant="danger" size="sm" className="w-full" onClick={() => onDelete?.(pet.id)}>Remove</Button>
            </div>
          ) : (
            <Button className="w-full group-hover:scale-[1.02]" onClick={() => onBook?.(pet.id)}>
              Request Booking
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default PetCard;