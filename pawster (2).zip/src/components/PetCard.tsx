import React from 'react';
import Button from './Button';
import { Pet } from '../types';

const toStringArray = (value: any): string[] => {
  if (Array.isArray(value)) return value.map(String);
  if (!value) return [];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map(String);
    } catch {}
    return value.split(/[,\n]/).map((v) => v.trim()).filter(Boolean);
  }
  return [String(value)];
};

interface Props {
  pet: Pet;
  onBook?: (id: string, rate?: number) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  isOwner?: boolean;
}

const PetCard: React.FC<Props> = ({
  pet,
  onBook,
  onEdit,
  onDelete,
  isOwner = false
}) => {
  const dos = toStringArray(pet.dos);
  const donts = toStringArray(pet.donts);

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all duration-200">
      <img
        src={pet.image_url}
        alt={pet.name}
        className="w-full h-56 object-cover"
      />

      <div className="p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-1">{pet.name}</h2>
        <p className="text-sm text-gray-500 mb-4">{pet.breed} • {pet.age} yr</p>

        {/* Dos & Don'ts */}
        <div className="mb-4">
          {dos.length > 0 && (
            <div className="mb-3">
              <h3 className="text-sm font-bold text-green-700">DO'S</h3>
              <ul className="list-disc list-inside text-sm text-gray-700">
                {dos.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          )}

          {donts.length > 0 && (
            <div>
              <h3 className="text-sm font-bold text-red-700">DON'TS</h3>
              <ul className="list-disc list-inside text-sm text-gray-700">
                {donts.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Rate */}
        <p className="text-pawster-teal font-bold mb-4">
          {pet.hourly_rate} Paw Credits / hr
        </p>

        {/* Buttons */}
        <div className="flex gap-3">
          {!isOwner && onBook && (
            <Button size="sm" onClick={() => onBook(pet.id, pet.hourly_rate)}>
              Book
            </Button>
          )}

          {isOwner && (
            <>
              {onEdit && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onEdit(pet.id)}
                >
                  Edit
                </Button>
              )}
              {onDelete && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onDelete(pet.id)}
                  className="text-red-600 border-red-300 hover:bg-red-50"
                >
                  Delete
                </Button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PetCard;
