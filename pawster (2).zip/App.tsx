import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthState } from './types';
import { supabase, isSupabaseConfigured } from './supabaseClient';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/Auth/LoginPage';
import SignupPage from './pages/Auth/SignupPage';
import ForgotPasswordPage from './pages/Auth/ForgotPasswordPage';
import DashboardPage from './pages/DashboardPage';
import ExplorePetsPage from './pages/ExplorePetsPage';
import CommunityPage from './pages/CommunityPage';
import PetForm from './pages/Pets/PetForm';

const App: React.FC = () => {
  const [authState, setAuthState] = useState<AuthState>(AuthState.LOADING);

  useEffect(() => {
    checkUser();
    
    // Listen for auth changes if supabase is valid
    if (isSupabaseConfigured()) {
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        setAuthState(session ? AuthState.AUTHENTICATED : AuthState.UNAUTHENTICATED);
      });
      // Correct cleanup using the returned subscription object
      return () => {
        if (data && data.subscription) {
          data.subscription.unsubscribe();
        }
      };
    }
  }, []);

  const checkUser = async () => {
    if (!isSupabaseConfigured()) {
      // If we are in preview mode without keys, we default to unauthenticated
      setAuthState(AuthState.UNAUTHENTICATED);
      return;
    }

    try {
      const { data, error } = await supabase.auth.getSession();
      if (error || !data) {
        setAuthState(AuthState.UNAUTHENTICATED);
      } else {
        setAuthState(data.session ? AuthState.AUTHENTICATED : AuthState.UNAUTHENTICATED);
      }
    } catch (e) {
      console.error("Auth check failed", e);
      setAuthState(AuthState.UNAUTHENTICATED);
    }
  };

  // Mock logout for preview / Real logout for Supabase
  const handleLogout = async () => {
    if (isSupabaseConfigured()) {
      await supabase.auth.signOut();
    } else {
      setAuthState(AuthState.UNAUTHENTICATED);
      window.location.hash = '/';
    }
  };

  // For preview mode: allows login page to force state change
  const handleMockLoginSuccess = () => {
    setAuthState(AuthState.AUTHENTICATED);
  };

  if (authState === AuthState.LOADING && isSupabaseConfigured()) {
    return (
      <div className="h-screen flex items-center justify-center bg-pawster-bg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pawster-teal"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-pawster-bg font-sans">
        <Navbar authState={authState} onLogout={handleLogout} />
        
        <main>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/explore" element={<ExplorePetsPage />} />
            <Route path="/community" element={<CommunityPage />} />
            
            {/* Auth Routes */}
            <Route 
              path="/login" 
              element={
                authState === AuthState.AUTHENTICATED 
                ? <Navigate to="/dashboard" /> 
                : <LoginPage onLoginSuccess={handleMockLoginSuccess} />
              } 
            />
            <Route 
              path="/signup" 
              element={
                authState === AuthState.AUTHENTICATED 
                ? <Navigate to="/dashboard" /> 
                : <SignupPage />
              } 
            />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />

            {/* Protected Routes */}
            <Route 
              path="/dashboard" 
              element={
                authState === AuthState.AUTHENTICATED 
                ? <DashboardPage /> 
                : <Navigate to="/login" />
              } 
            />
            <Route 
              path="/pets/new" 
              element={
                authState === AuthState.AUTHENTICATED 
                ? <PetForm /> 
                : <Navigate to="/login" />
              } 
            />
            <Route 
              path="/pets/edit/:id" 
              element={
                authState === AuthState.AUTHENTICATED 
                ? <PetForm /> 
                : <Navigate to="/login" />
              } 
            />
          </Routes>
        </main>

        <footer className="bg-white border-t border-gray-100 mt-20 py-10 text-center">
           <p className="text-gray-400 text-sm">&copy; {new Date().getFullYear()} Pawster. Made with ❤️ for pets.</p>
        </footer>
      </div>
    </Router>
  );
};

export default App;