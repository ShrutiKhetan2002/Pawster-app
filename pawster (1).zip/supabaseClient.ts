import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://rpxzhwcygeodqqinklwb.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJweHpod2N5Z2VvZHFxaW5rbHdiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxNjMwNjgsImV4cCI6MjA3OTczOTA2OH0.F7FmOP34g9_Qcnskn6PNrVeTS-vJIIWsJLIsBzz1HvI";

export const isSupabaseConfigured = () => {
  return !!SUPABASE_URL && !!SUPABASE_ANON_KEY;
};

// Use placeholders if config is missing to avoid runtime crash on initialization
// The app logic should rely on isSupabaseConfigured() to decide whether to use the client.
const url = SUPABASE_URL || "https://placeholder.supabase.co";
const key = SUPABASE_ANON_KEY || "placeholder";

export const supabase = createClient(url, key);