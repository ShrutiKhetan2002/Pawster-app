import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthState } from '../types';
import Button from './Button';

interface NavbarProps {
  authState: AuthState;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ authState, onLogout }) => {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => {
    return location.pathname === path 
      ? "text-pawster-primary font-bold" 
      : "text-pawster-textLight hover:text-pawster-primary transition-colors duration-200";
  }

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/80 backdrop-blur-xl border-b border-white/20 shadow-soft' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-gradient-to-br from-pawster-primary to-pawster-primaryDark rounded-xl flex items-center justify-center text-white text-xl shadow-lg shadow-pawster-primary/30 transform transition-transform group-hover:rotate-6">
              <span className="mb-1">🐾</span>
            </div>
            <span className="font-sans font-extrabold text-2xl text-pawster-text tracking-tight">
              Pawster
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            <div className="flex bg-gray-100/50 p-1 rounded-full mr-4">
              <Link to="/explore" className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${isActive('/explore') ? 'bg-white shadow-sm text-pawster-primary' : ''}`}>Explore</Link>
              <Link to="/community" className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${isActive('/community') ? 'bg-white shadow-sm text-pawster-primary' : ''}`}>Community</Link>
            </div>
            
            {authState === AuthState.AUTHENTICATED ? (
              <>
                <Link to="/dashboard" className={`mr-4 text-sm font-medium ${isActive('/dashboard')}`}>Dashboard</Link>
                <div className="flex items-center gap-3 pl-2 border-l border-gray-200">
                  <Button variant="ghost" size="sm" onClick={onLogout}>Sign Out</Button>
                  <Link to="/pets/new">
                     <Button size="sm">List a Pet</Button>
                  </Link>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="px-4 py-2 font-semibold text-sm text-gray-600 hover:text-pawster-primary transition-colors">Log In</Link>
                <Link to="/signup">
                  <Button size="sm">Sign Up</Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-lg bg-gray-50 text-gray-600 hover:bg-gray-100 focus:outline-none"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isMenuOpen ? (
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-xl border-t border-gray-100 absolute w-full left-0 shadow-xl animate-fade-in-up">
          <div className="px-6 py-6 space-y-4">
            <Link to="/explore" className="block text-lg font-medium text-gray-700" onClick={() => setIsMenuOpen(false)}>Explore Pets</Link>
            <Link to="/community" className="block text-lg font-medium text-gray-700" onClick={() => setIsMenuOpen(false)}>Community</Link>
            
            <div className="border-t border-gray-100 my-4"></div>
            
            {authState === AuthState.AUTHENTICATED ? (
              <>
                <Link to="/dashboard" className="block text-lg font-medium text-gray-700" onClick={() => setIsMenuOpen(false)}>Dashboard</Link>
                <div className="pt-4 flex flex-col gap-3">
                   <Link to="/pets/new" onClick={() => setIsMenuOpen(false)}>
                      <Button className="w-full">List a Pet</Button>
                   </Link>
                   <Button variant="outline" className="w-full" onClick={() => { onLogout(); setIsMenuOpen(false); }}>Sign Out</Button>
                </div>
              </>
            ) : (
              <div className="flex flex-col gap-3">
                 <Link to="/login" onClick={() => setIsMenuOpen(false)}>
                   <Button variant="outline" className="w-full">Log In</Button>
                 </Link>
                 <Link to="/signup" onClick={() => setIsMenuOpen(false)}>
                   <Button className="w-full">Sign Up</Button>
                 </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;