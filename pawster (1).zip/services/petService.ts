import { supabase } from '../supabaseClient';
import { Pet } from '../types';

export const petService = {
  getAllPets: async (): Promise<Pet[]> => {
    const { data, error } = await supabase.from('pets').select('*');
    if (error) throw error;
    return data || [];
  },

  getMyPets: async (userId: string): Promise<Pet[]> => {
    const { data, error } = await supabase
      .from('pets')
      .select('*')
      .eq('owner_id', userId);

    if (error) throw error;
    return data || [];
  },

  createPet: async (pet: Omit<Pet, 'id' | 'owner_id'>): Promise<Pet | null> => {
    // Always attach current user as owner
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      throw new Error("You must be logged in to create a pet.");
    }

    const { data, error } = await supabase
      .from('pets')
      .insert([
        {
          ...pet,
          owner_id: user.id,
        },
      ])
      .select();

    if (error) throw error;
    return data ? (data[0] as Pet) : null;
  },

  updatePet: async (id: string, updates: Partial<Pet>): Promise<Pet | null> => {
    const { data, error } = await supabase
      .from('pets')
      .update(updates)
      .eq('id', id)
      .select();

    if (error) throw error;
    return data ? (data[0] as Pet) : null;
  },

  deletePet: async (id: string): Promise<void> => {
    const { error } = await supabase.from('pets').delete().eq('id', id);
    if (error) throw error;
  }
};