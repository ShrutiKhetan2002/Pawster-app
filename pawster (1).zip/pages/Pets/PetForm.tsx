import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Pet } from '../../types';
import { petService } from '../../services/petService';
import Button from '../../components/Button';

const PetForm: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;

  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Partial<Pet>>({
    name: '',
    species: 'Dog',
    breed: '',
    age: 0,
    temperament: '',
    description: '',
    dos: [],
    donts: [],
    hourly_rate: 15,
    image_url: 'https://picsum.photos/800/600',
  });

  const [doInput, setDoInput] = useState('');
  const [dontInput, setDontInput] = useState('');

  // helper: always give us a string[]
  const toStringArray = (value: any): string[] => {
    if (Array.isArray(value)) return value.map(String);
    if (value == null) return [];
    if (typeof value === 'string') {
      // if it happens to be a JSON array string, try to parse
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return parsed.map(String);
      } catch {
        // ignore JSON parse error, fall back to split
      }
      return value
        .split(/\r?\n|,/)
        .map((s) => s.trim())
        .filter(Boolean);
    }
    return [String(value)];
  };

  useEffect(() => {
    if (isEditing && id) {
      loadPet(id);
    }
  }, [id, isEditing]);

  const loadPet = async (petId: string) => {
    setLoading(true);
    try {
      // simple: reuse getAllPets and find the one
      const pets = await petService.getAllPets();
      const found = pets.find((p) => p.id === petId);
      if (found) {
        setFormData({
          ...found,
          temperament: found.temperament || '',
          description: found.description || '',
          image_url: found.image_url || '',
          dos: toStringArray(found.dos),
          donts: toStringArray(found.donts),
        });
      }
    } catch (err) {
      console.error('Failed to load pet for editing:', err);
      alert('Could not load pet details.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload: Partial<Pet> = {
        ...formData,
        dos: toStringArray(formData.dos),
        donts: toStringArray(formData.donts),
      };

      if (isEditing && id) {
        await petService.updatePet(id, payload as Pet);
      } else {
        await petService.createPet(payload as Pet);
      }
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
      alert('Failed to save pet');
    } finally {
      setLoading(false);
    }
  };

  const handleArrayAdd = (type: 'dos' | 'donts', value: string) => {
    if (!value.trim()) return;
    setFormData((prev) => {
      const current = toStringArray(prev[type]);
      return {
        ...prev,
        [type]: [...current, value.trim()],
      };
    });
    if (type === 'dos') setDoInput('');
    else setDontInput('');
  };

  const handleArrayRemove = (type: 'dos' | 'donts', index: number) => {
    setFormData((prev) => {
      const current = toStringArray(prev[type]);
      return {
        ...prev,
        [type]: current.filter((_, i) => i !== index),
      };
    });
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:ring-2 focus:ring-pawster-teal focus:border-transparent outline-none transition-all duration-200';
  const labelClass =
    'block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide text-xs';

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-[2.5rem] shadow-xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
        {/* Header */}
        <div className="bg-pawster-teal px-10 py-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full translate-x-10 -translate-y-10"></div>
          <div className="relative z-10">
            <h1 className="text-3xl font-extrabold text-white mb-2">
              {isEditing ? 'Edit Pet Profile' : 'List a New Pet'}
            </h1>
            <p className="text-teal-50">
              Fill in the details to help borrowers connect with your pet.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-10 space-y-10">
          {/* Section 1: Basic Info */}
          <section>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-pawster-beige flex items-center justify-center text-sm">
                1
              </span>
              Basic Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className={labelClass}>Pet Name</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Barnaby"
                  value={formData.name || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Species</label>
                <select
                  value={formData.species || 'Dog'}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      species: e.target.value as any,
                    })
                  }
                  className={inputClass}
                >
                  <option value="Dog">Dog</option>
                  <option value="Cat">Cat</option>
                  <option value="Bird">Bird</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>Breed</label>
                <input
                  type="text"
                  placeholder="e.g. Golden Retriever"
                  value={formData.breed || ''}
                  onChange={(e) =>
                    setFormData({ ...formData, breed: e.target.value })
                  }
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Age (Years)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.age ?? 0}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      age: parseInt(e.target.value || '0', 10),
                    })
                  }
                  className={inputClass}
                />
              </div>
            </div>
          </section>

          <hr className="border-gray-100" />

          {/* Section 2: Details */}
          <section>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-pawster-beige flex items-center justify-center text-sm">
                2
              </span>
              Personality
            </h3>

            <div className="space-y-6">
              <div>
                <label className={labelClass}>Temperament Tags</label>
                <input
                  type="text"
                  placeholder="e.g. Friendly, Energetic, Shy (Comma separated)"
                  value={formData.temperament || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      temperament: e.target.value,
                    })
                  }
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Bio / Description</label>
                <textarea
                  rows={4}
                  value={formData.description || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      description: e.target.value,
                    })
                  }
                  className={inputClass}
                  placeholder="Tell us what makes your pet special, their favorite toys, and what a perfect playdate looks like..."
                />
              </div>

              <div>
                <label className={labelClass}>Image URL (Demo)</label>
                <input
                  type="text"
                  value={formData.image_url || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      image_url: e.target.value,
                    })
                  }
                  className={inputClass}
                />
              </div>
            </div>
          </section>

          <hr className="border-gray-100" />

          {/* Section 3: Rules */}
          <section>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-pawster-beige flex items-center justify-center text-sm">
                3
              </span>
              Care Instructions
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-green-50 p-6 rounded-3xl border border-green-100">
                <label className="block text-sm font-extrabold text-green-800 mb-3 flex items-center gap-2">
                  <span>✅</span> DO&apos;S
                </label>
                <div className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={doInput}
                    onChange={(e) => setDoInput(e.target.value)}
                    className="flex-1 px-4 py-2 rounded-xl border border-green-200 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
                    placeholder="Add a requirement..."
                    onKeyDown={(e) =>
                      e.key === 'Enter' &&
                      (e.preventDefault(), handleArrayAdd('dos', doInput))
                    }
                  />
                  <button
                    type="button"
                    onClick={() => handleArrayAdd('dos', doInput)}
                    className="bg-green-500 text-white rounded-xl w-10 h-10 font-bold hover:bg-green-600 transition"
                  >
                    +
                  </button>
                </div>
                <ul className="space-y-2">
                  {toStringArray(formData.dos).map((item, idx) => (
                    <li
                      key={idx}
                      className="bg-white px-3 py-2 rounded-lg text-sm text-green-900 flex justify-between shadow-sm border border-green-50"
                    >
                      {item}
                      <button
                        type="button"
                        onClick={() => handleArrayRemove('dos', idx)}
                        className="text-red-300 hover:text-red-500 font-bold px-2"
                      >
                        ×
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                <label className="block text-sm font-extrabold text-red-800 mb-3 flex items-center gap-2">
                  <span>❌</span> DON&apos;TS
                </label>
                <div className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={dontInput}
                    onChange={(e) => setDontInput(e.target.value)}
                    className="flex-1 px-4 py-2 rounded-xl border border-red-200 text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                    placeholder="Add a restriction..."
                    onKeyDown={(e) =>
                      e.key === 'Enter' &&
                      (e.preventDefault(), handleArrayAdd('donts', dontInput))
                    }
                  />
                  <button
                    type="button"
                    onClick={() => handleArrayAdd('donts', dontInput)}
                    className="bg-red-500 text-white rounded-xl w-10 h-10 font-bold hover:bg-red-600 transition"
                  >
                    +
                  </button>
                </div>
                <ul className="space-y-2">
                  {toStringArray(formData.donts).map((item, idx) => (
                    <li
                      key={idx}
                      className="bg-white px-3 py-2 rounded-lg text-sm text-red-900 flex justify-between shadow-sm border border-red-50"
                    >
                      {item}
                      <button
                        type="button"
                        onClick={() => handleArrayRemove('donts', idx)}
                        className="text-red-300 hover:text-red-500 font-bold px-2"
                      >
                        ×
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          {/* Rate */}
          <div className="bg-gray-50 p-6 rounded-2xl flex items-center justify-between">
            <label className="text-lg font-bold text-gray-700">
              Hourly Rate (Paw Credits)
            </label>
            <div className="relative w-32">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold">
                $
              </span>
              <input
                type="number"
                min="0"
                required
                value={formData.hourly_rate ?? 0}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    hourly_rate: parseInt(e.target.value || '0', 10),
                  })
                }
                className="w-full pl-8 pr-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-pawster-teal focus:outline-none font-bold text-xl text-center"
              />
            </div>
          </div>

          <div className="pt-8 flex gap-4">
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="flex-1"
              onClick={() => navigate('/dashboard')}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              size="lg"
              className="flex-[2] shadow-xl"
              isLoading={loading}
            >
              {isEditing ? 'Save Changes' : 'Publish Listing'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PetForm;
