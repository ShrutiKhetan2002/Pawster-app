import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import { supabase, isSupabaseConfigured } from '../../supabaseClient';

const SignupPage: React.FC = () => {
  const [name, setName] = useState('');
  const [batch, setBatch] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // If Supabase isn't configured, just simulate a success and go to login
      if (!isSupabaseConfigured()) {
        await new Promise((r) => setTimeout(r, 1000));
        alert('Supabase not configured in this environment. Simulating signup.');
        navigate('/login');
        return;
      }

      // 1) Create auth user
      const { data, error: signupError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (signupError) {
        throw signupError;
      }

      const user = data?.user;
      if (!user) {
        throw new Error('User not returned from sign up.');
      }

      // 2) Insert into profiles table
      const { error: profileError } = await supabase.from('profiles').insert({
        id: user.id,
        name,
        email,
        batch,
      });

      if (profileError) {
        console.error('Error inserting into profiles:', profileError);
        // Not fatal for login, but good to tell the user
        alert('Signed up, but failed to save profile details: ' + profileError.message);
      } else {
        alert('Signup successful! Please check your email for confirmation (if enabled).');
      }

      navigate('/login');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to sign up');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-2xl shadow-sm border border-gray-100">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Join Pawster</h2>
          <p className="mt-2 text-sm text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-pawster-teal hover:text-pawster-tealDark">
              Log in
            </Link>
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleSignup}>
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Full name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawster-teal focus:border-pawster-teal sm:text-sm"
              />
            </div>

            <div>
              <label htmlFor="batch" className="block text-sm font-medium text-gray-700">
                Batch
              </label>
              <input
                id="batch"
                name="batch"
                type="text"
                required
                placeholder="e.g. Batch 1"
                value={batch}
                onChange={(e) => setBatch(e.target.value)}
                className="mt-1 appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawster-teal focus:border-pawster-teal sm:text-sm"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawster-teal focus:border-pawster-teal sm:text-sm"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-pawster-teal focus:border-pawster-teal sm:text-sm"
              />
            </div>
          </div>

          <Button type="submit" className="w-full" isLoading={loading} size="lg">
            Create Account
          </Button>
        </form>
      </div>
    </div>
  );
};

export default SignupPage;
