import React, { useEffect, useState } from 'react';
import { Pet } from '../types';
import { supabase } from "../supabaseClient";
import PetCard from '../components/PetCard';

const ExplorePetsPage: React.FC = () => {
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    loadPets();
  }, []);

  const loadPets = async () => {
    try {
      const { data, error } = await supabase.from("pets").select("*");
      if (error) { console.error(error); return; }
      setPets(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRequestBooking = async (petId: string, hourlyRate: number) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        alert("You must be logged in to request a booking.");
        return;
      }
      const start = new Date();
      const end = new Date(start.getTime() + 60 * 60 * 1000);
      const { error } = await supabase.from("bookings").insert({
        pet_id: petId,
        borrower_id: user.id,
        start_time: start.toISOString(),
        end_time: end.toISOString(),
        total_amount: hourlyRate,
        status: "pending",
      });
      if (error) throw error;
      alert(`Booking request sent for pet ID: ${petId}!`);
    } catch (err: any) {
      alert("Booking failed: " + err.message);
    }
  };

  const filteredPets = filter === 'All' ? pets : pets.filter((p) => p.species === filter);
  const categories = ['All', 'Dog', 'Cat', 'Bird', 'Other'];

  return (
    <div className="min-h-screen bg-pawster-bg">
      <div className="bg-white border-b border-gray-100 pb-12 pt-12">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex flex-col md:flex-row justify-between items-end gap-6">
            <div>
              <h1 className="text-4xl font-extrabold text-slate-900 mb-3 tracking-tight">Explore Pets</h1>
              <p className="text-slate-500 font-medium text-lg">Find the perfect companion for a few hours.</p>
            </div>

            {/* Modern Filters */}
            <div className="flex flex-wrap gap-2 bg-slate-50 p-1.5 rounded-full border border-slate-100">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all duration-300 ${
                    filter === cat
                      ? "bg-white text-pawster-primary shadow-md transform scale-105"
                      : "text-slate-500 hover:text-slate-700 hover:bg-slate-200/50"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-7xl">
        {loading ? (
          <div className="flex justify-center py-32">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pawster-primary"></div>
          </div>
        ) : filteredPets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredPets.map((pet) => (
              <PetCard
                key={pet.id}
                pet={pet}
                onBook={(id) => handleRequestBooking(id, pet.hourly_rate)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-32 bg-white rounded-[3rem] border border-dashed border-slate-200 shadow-sm mx-auto max-w-2xl">
            <div className="text-7xl mb-6 opacity-30 grayscale">🐶</div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">
              No pets found
            </h3>
            <p className="text-slate-500 mb-8">Try adjusting your filters to see more results.</p>
            <button
              className="px-8 py-3 bg-slate-100 rounded-full text-slate-700 font-bold hover:bg-slate-200 transition-colors"
              onClick={() => setFilter('All')}
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExplorePetsPage;