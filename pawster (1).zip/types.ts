export interface Pet {
  id: string;
  owner_id: string;
  name: string;
  species: 'Dog' | 'Cat' | 'Bird' | 'Other';
  breed: string;
  age: number;
  temperament: string;
  description: string;
  dos: string[];
  donts: string[];
  hourly_rate: number;
  image_url: string;
}

export interface UserProfile {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  paw_credits: number;
  role: 'owner' | 'borrower';
}

export interface CommunityPost {
  id: string;
  author_name: string;
  title: string;
  content: string;
  likes: number;
  created_at: string;
  tags: string[];
}

export enum AuthState {
  LOADING,
  AUTHENTICATED,
  UNAUTHENTICATED,
}
